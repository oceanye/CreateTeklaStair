﻿using Autodesk.Revit.ApplicationServices;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//using Excel = Microsoft.Office.Interop.Excel;
namespace Namespace
{
    [Autodesk.Revit.Attributes.Transaction(Autodesk.Revit.Attributes.TransactionMode.Manual)]
    public class Class1 : IExternalCommand
    {
        public Result Execute(ExternalCommandData revit, ref string message, ElementSet elements)
        {
            UIDocument uidoc = revit.Application.ActiveUIDocument;
            Document doc = uidoc.Document;
            FamilySymbol fs = null;

            //过滤钢筋类型
            FilteredElementCollector sybols = new FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_GenericModel).OfClass(typeof(FamilySymbol));


            FilteredElementCollector collector = new FilteredElementCollector(doc);
            var columns = collector.OfClass(typeof(FamilyInstance));


            string info = "";
            foreach (FamilyInstance item in columns)
            {
                string id = item.Id.ToString();
                string name = item.Symbol.FamilyName;
                string syname=item.Symbol.Name;

                string xyzs = null;
                info += id + "," + name + "," + syname+"\r\n";

               


                Options options = new Options();

                GeometryElement geometry = item.get_Geometry(options);

                int i = 0;

                foreach (GeometryObject obj in geometry)
                {
                    GeometryInstance instance = obj as GeometryInstance;

                    GeometryElement geometryElement = instance.GetInstanceGeometry();

                    foreach (GeometryObject elem in geometryElement)
                    {
                        Solid solid = elem as Solid;
                     
                        if(solid != null)
                        {
                            EdgeArray faceArray = solid.Edges;

                            foreach (Edge ed in faceArray)
                            {
                                Curve cu = ed.AsCurve();
                                if(cu != null)
                                {
                                    XYZ xyz1 = cu.GetEndPoint(0);
                                    XYZ xyz2 = cu.GetEndPoint(1);
                                    xyzs+=xyz1 +","+ xyz2;  

                                }
                            }
                        }

                    }
                }
                info += xyzs + "\r\n";

            }

            TaskDialog.Show(info, info);









            return Result.Succeeded;
        }
    }
}
